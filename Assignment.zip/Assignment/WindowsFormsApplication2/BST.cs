﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BST
{
    class Node<T> : IComparable where T : IComparable
    {
        #region Properties   
        public T value;
        public String name;
        public T day;
        public T month;
        public T year;
        public double cumulativeAverageScore;
        public T cumulativeNumberOfCredits;

        public Node<T> left { get; set; }
        public Node<T> right { get; set; }
        public Node<T> parent { get; set; }

        public bool Isleaf
        {
            get { return left == null && right == null; }
        }

        public bool HasLeft
        {
            get { return left != null; }
        }

        public bool HasRight
        {
            get { return right != null; }
        }

        public override int GetHashCode()
        {
            return this.value.GetHashCode();
        }
        #endregion

        public Node(T value, String name, T day, T month, T year, double cumulativeAverageScore, T cumulativeNumberOfCredits)
        {
            this.value = value;
            this.name = name;
            this.day = day;
            this.month = month;
            this.year = year;
            this.cumulativeAverageScore = cumulativeAverageScore;
            this.cumulativeNumberOfCredits = cumulativeNumberOfCredits;
        }


        public void setName(String name)
        {
            this.name = name;
        }

        public void setBD(T day, T month, T year)
        {
            this.day = day;
            this.month = month;
            this.year = year;
        }

        public void setAverageScore(double cumulativeAverageScore)
        {
            this.cumulativeAverageScore = cumulativeAverageScore;
        }

        public void setNumberOfCredits (T cumulativeNumberOfCredits)
        {
            this.cumulativeNumberOfCredits = cumulativeNumberOfCredits;
        }
        #region IComparable Members

        public int CompareTo(object obj)
        {
            Node<T> node = obj as Node<T>;

            return this.value.CompareTo(node.value);
        }
        #endregion
    }

    class BST<T> where T : IComparable
    {
        #region Properties

        public Node<T> root { get; set; }
        private List<String> list;
        public int count { get; private set; }

        #endregion

        public BST()
        {
            count = 0;
            list = new List<String>();
        }

        public BST(T value, String name, T day, T month, T year, double cumulativeAverageScore, T cumulativeNumberOfCredits)
            : this()
        {
            addNode(value, name, day, month, year, cumulativeAverageScore, cumulativeNumberOfCredits);
        }

        #region LNR
        public virtual List<String> LNR()
        {
            list.Clear();
            LNR(root);
            return list;
        }

        private void LNR(Node <T> node)
        {
            if (node != null)
            {
                LNR(node.left);
                list.Add(node.value + " " + node.name +" " + node.day +"/" + node.month +"/" + node.year + " " + node.cumulativeAverageScore + " " + node.cumulativeNumberOfCredits);
                LNR(node.right);
            }
        }
        #endregion

        #region LRN
        public virtual List<String> LRN()
        {
            list.Clear();
            LRN(root);
            return list;
        }

        private void LRN(Node<T> node)
        {
            if (node != null)
            {
                LRN(node.left);
                LRN(node.right);
                list.Add(node.value + " " + node.name + " " + node.day + "/" + node.month + "/" + node.year + " " + node.cumulativeAverageScore + " " + node.cumulativeNumberOfCredits);
            }
        }
        #endregion

        #region NLR
        public virtual List<String> NLR()
        {
            list.Clear();
            NLR(root);
            return list;
        }

        private void NLR(Node<T> node)
        {
            if (node != null)
            {
                list.Add(node.value + " " + node.name + " " + node.day + "/" + node.month + "/" + node.year + " " + node.cumulativeAverageScore + " " + node.cumulativeNumberOfCredits);
                NLR(node.left);
                NLR(node.right);
            }
        }
        #endregion

        #region RNL
        public virtual List<String> RNL()
        {
            list.Clear();
            RNL(root);
            return list;
        }

        private void RNL(Node<T> node)
        {
            if (node != null)
            {
                RNL(node.right);
                list.Add(node.value + " " + node.name + " " + node.day + "/" + node.month + "/" + node.year + " " + node.cumulativeAverageScore + " " + node.cumulativeNumberOfCredits);
                RNL(node.left);
            }
        }
        #endregion

        #region NRL
        public virtual List<String> NRL()
        {
            list.Clear();
            NRL(root);
            return list;
        }

        private void NRL(Node<T> node)
        {
            if (node != null)
            {
                list.Add(node.value + " " + node.name + " " + node.day + "/" + node.month + "/" + node.year + " " + node.cumulativeAverageScore + " " + node.cumulativeNumberOfCredits);
                NRL(node.right);
                NRL(node.left);
            }
        }
        #endregion


        #region RLN
        public virtual List<String> RLN()
        {
            list.Clear();
            RLN(root);
            return list;
        }

        private void RLN(Node<T> node)
        {
            if (node != null)
            {
                RLN(node.right);
                RLN(node.left);
                list.Add(node.value + " " + node.name + " " + node.day + "/" + node.month + "/" + node.year + " " + node.cumulativeAverageScore + " " + node.cumulativeNumberOfCredits);
            }
        }
        #endregion

        #region Add Node

        public virtual bool addNode(T value, String name, T day, T month, T year, double cumulativeAverageScore, T cumulativeNumberOfCredits)
        {
            Node<T> node = new Node<T>(value, name, day, month, year, cumulativeAverageScore, cumulativeNumberOfCredits);
            if (root == null)
            {
                count++;
                root = node;
                return true;
            }

            return addNode(root, node);
        }

        private bool addNode(Node<T> parentNode, Node<T> node)
        {
            if (parentNode.value.Equals(node.value))
                return false;

            if (parentNode.value.CompareTo(node.value) > 0)
            {
                if (!parentNode.HasLeft)
                {

                    parentNode.left = node;
                    node.parent = parentNode;
                    count++;
                    return true;
                }
                else
                    return addNode(parentNode.left, node);
            }
            else
            {
                if (!parentNode.HasRight)
                {
                    parentNode.right = node;
                    node.parent = parentNode;
                    count++;
                    return true;
                }
                else
                    return addNode(parentNode.right, node);
            }
        }
        #endregion
        public virtual void ClearChildren(Node<T> node)
        {

            if (node.HasLeft)
            {
                ClearChildren(node.left);
                node.left.parent = null;
                node.left = null;
            }
            if (node.HasRight)
            {
                ClearChildren(node.right);
                node.right.parent = null;
                node.right = null;
            }
        }

        public virtual void Clear()
        {
            if (root == null)
                return;
            ClearChildren(root);
            root = null;
            count = 0;
        }

        public virtual int GetHeight()
        {
            return this.GetHeight(this.root);
        }
        private int GetHeight(Node<T> startNode)
        {
            if (startNode == null)
                return 0;
            else
                return 1 + Math.Max(GetHeight(startNode.left), GetHeight(startNode.right));
        }

        public virtual Queue<T> findPathKey(T key)
        {
            Queue<T> q = new Queue<T>();

            Node<T> node = this.root;
            bool isFounded = false;
            
            while (node != null)
            {
                if (node.value.Equals(key))
                {
                    isFounded = true;
                    break;
                }
                else
                {
                    if (node.value.CompareTo(key) > 0)
                        node = node.left;
                    else
                        node = node.right;
                    
                    if (node != null) q.Enqueue(node.value);
                }
            }
            if (!isFounded)
            {
                
                q.Clear();
                q = null;
            }
            return q;
        }

        public virtual Queue<T> findPathName(T key, String name)
        {
            Queue<T> q = new Queue<T>();

            Node<T> node = this.root;
            bool isFounded = false;

            while (node != null)
            {

              //  Console.WriteLine(name);
                if (node.name.Equals(name) && node.value.Equals(key))
                {
                    
                    isFounded = true;
                    break;
                }
                else
                {
                  //  Console.WriteLine(node.name);
                    if (node.value.CompareTo(key) > 0)
                        node = node.left;
                    else
                        node = node.right;

                    if (node != null) q.Enqueue(node.value);
                }
            }
            if (!isFounded)
            {

                q.Clear();
                q = null;
            }
            return q;
        }

        public virtual Queue<T> findPathBD(T key, T day, T month, T year)
        {
            Queue<T> q = new Queue<T>();


            bool isFounded = false;
            Node<T> node = this.root;

            while (node != null)
            {
                 if (node.day.Equals(day) && node.month.Equals(month) && node.year.Equals(year) && node.value.Equals(key))
                 {
                    isFounded = true;
                    break;
                 }
                else
                {
                    if (node.value.CompareTo(key) > 0)
                        node = node.left;
                    else
                        node = node.right;

                    if (node != null) q.Enqueue(node.value);
                }
            }
            if (!isFounded)
            {

                q.Clear();
                q = null;
            }
            return q;
        }

        public virtual Queue<T> findPathAverageScore(T key ,double AverageScore)
        {
            Queue<T> q = new Queue<T>();


            bool isFounded = false;
            Node<T> node = this.root;

            while (node != null)
            {

                if (node.cumulativeAverageScore.Equals(AverageScore) && node.value.Equals(key))
                {

                    isFounded = true;
                    break;
                }
                else
                {
                    if (node.value.CompareTo(key) > 0)
                        node = node.left;
                    else
                        node = node.right;

                    if (node != null) q.Enqueue(node.value);
                }
            }
            if (!isFounded)
            {

                q.Clear();
                q = null;
            }
            return q;
        }
        public virtual Queue<T> findPathNumberOfCredits(T key, int NumberOfCredits)
        {
            Queue<T> q = new Queue<T>();


            bool isFounded = false;
            Node<T> node = this.root;

            while (node != null)
            {

                if (node.cumulativeNumberOfCredits.Equals(NumberOfCredits) && node.value.Equals(key))
                {
                    isFounded = true;
                    break;
                }
                else
                {
                    if (node.value.CompareTo(key) > 0)
                        node = node.left;
                    else
                        node = node.right;

                    if (node != null) q.Enqueue(node.value);
                }
            }
            if (!isFounded)
            {

                q.Clear();
                q = null;
            }
            return q;
        }

        public virtual Queue<T> findPathMin()
        {
            Queue<T> q = new Queue<T>();
            Node<T> node = this.root;

            while (node.left != null)
            {
                if (node.HasLeft) node = node.left;
                if (node != null) q.Enqueue(node.value);
            }
            return q;
        }

        public virtual Queue<T> findPathMax()
        {
            Queue<T> q = new Queue<T>();
            Node<T> node = this.root;

            while (node.right != null)
            {
                if (node.HasRight) node = node.right;
                if (node != null) q.Enqueue(node.value);
            }
            return q;
        }

        private Node<T> min(Node<T> node)
        {
            while (node.HasLeft)
            {
                node = node.left;
            }

            return node;
        }

        public Node<T> successor(Node<T> node, Node<T> suc, T key)
        {
            while (node != null)
            {
                if (node.value.Equals(key))
                {
                    if (node.HasRight)
                    {
                        return min(node.right);
                    }
                    else
                    {
                        return suc;
                    }
                }
                else if (node.value.CompareTo(key) < 0)
                {

                    node = node.right;
                }
                else if (node.value.CompareTo(key) > 0)
                {
                    suc = node;
                    node = node.left;
                }
            }

            return suc;
        }

        private Node<T> max(Node<T> node)
        {
            while (node.HasRight)
            {
                node = node.right;
            }

            return node;
        }

        public Node<T> Predecessor(Node<T> node, Node<T> pre, T key)
        {

            while (node != null)
            {
                if (node == null)
                    return pre;

                if (node.value.Equals(key))
                {
                    if (node.HasLeft)
                    {
                        pre = max(node.left);
                        return pre;
                    }
                    else
                    {
                        return pre;
                    }
                }
                else if (node.value.CompareTo(key) < 0)
                {
                    pre = node;
                    //Console.WriteLine(node.value);
                    node = node.right;
                }
                else if (node.value.CompareTo(key) > 0)
                {
                   // Console.WriteLine(node.value);
                    node = node.left;
                }
            }
            return pre;
        }

        public void updateName(T key, String name)
        {
            Node<T> node = this.root;
            while(node != null)
            {
                if (node.value.Equals(key))
                {
                    node.setName(name);
                    break;
                }
                else if (node.value.CompareTo(key) < 0)
                {
                    node = node.right;
                }
                else
                {
                    node = node.left;
                }
            }
        }

        public void updateBD(T key, T day, T month, T year)
        {
            Node<T> node = this.root;
            while (node != null)
            {
                if (node.value.Equals(key))
                {
                    node.setBD(day, month, year);
                    break;
                }
                else if (node.value.CompareTo(key) < 0)
                {
                    node = node.right;
                }
                else
                {
                    node = node.left;
                }
            }
        }

        public void updateAverageScore(T key, double Score)
        {
            Node<T> node = this.root;
            while (node != null)
            {
                if (node.value.Equals(key))
                {
                    node.setAverageScore(Score);
                    break;
                }
                else if (node.value.CompareTo(key) < 0)
                {
                    node = node.right;
                }
                else
                {
                    node = node.left;
                }
            }
        }

        public void updateNumberOfCredits(T key, T Score)
        {
            Node<T> node = this.root;
            while (node != null)
            {
                if (node.value.Equals(key))
                {
                    node.setNumberOfCredits(Score);
                    break;
                }
                else if (node.value.CompareTo(key) < 0)
                {
                    node = node.right;
                }
                else
                {
                    node = node.left;
                }
            }
        }

        public virtual bool Remove(T value)
        {
            return Remove(root, value);
        }

        private bool Remove(Node<T> node, T value)
        {
            if (node == null)
                return false;

            if (node.value.Equals(value))
            {
                if (node.Isleaf) // no children
                {
                    if (node.parent.left == node)
                        node.parent.left = null;
                    else
                        node.parent.right = null;

                    node.parent = null;
                }
                else if (node.HasLeft && node.HasRight)   // 2 children
                {
                    // Tìm successor node
                    Node<T> replacementNode = node.right;

                    while (replacementNode.HasLeft)
                    {
                        replacementNode = replacementNode.left;
                    }
                    node.value = replacementNode.value;

                    Remove(replacementNode, replacementNode.value);
                }
                else    // one child
                {
                    Node<T> subNode;

                    if (node.HasLeft)
                        subNode = node.left;
                    else
                        subNode = node.right;

                    if (root == (subNode))
                        root = subNode;

                    subNode.parent = node.parent;

                    if (node.parent.left == node)
                        node.parent.left = subNode;
                    else
                        node.parent.right = subNode;
                }
                count--;
                return true;
            }
            else
            {
                if (node.value.CompareTo(value) > 0)
                    return Remove(node.left, value);
                else
                    return Remove(node.right, value);
            }
        }
    }
}
