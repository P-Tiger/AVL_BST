﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class BST_From : Form
    {
        public BST_From()
        {
            InitializeComponent();
            saveFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        }

        private void random_Click(object sender, EventArgs e)
        {
            bsTreePanel1.randomTree();
        }

        private void empty_Click(object sender, EventArgs e)
        {
            bsTreePanel1.empty();
        }

        private void skewebLeft_Click(object sender, EventArgs e)
        {
            bsTreePanel1.skewebLeft();
        }

        private void skewebRight_Click(object sender, EventArgs e)
        {
            bsTreePanel1.skewebRight();
        }

        private void LNRButton_Click(object sender, EventArgs e)
        {
            bsTreePanel1.LNR();
        }

        private void NRLButton_Click(object sender, EventArgs e)
        {
            bsTreePanel1.NRL();
        }

        private void RNLButton_Click(object sender, EventArgs e)
        {
            bsTreePanel1.RNL();
        }

        private void NLRButton_Click(object sender, EventArgs e)
        {
            bsTreePanel1.NLR();
        }

        private void LRNButton_Click(object sender, EventArgs e)
        {
            bsTreePanel1.LRN();
        }

        private void RLNButton_Click(object sender, EventArgs e)
        {
            bsTreePanel1.RLN();
        }

        private void addButton_Click(object sender, EventArgs e)
        { 
            for (int i = 0; i < textBox1.Lines.Length; i++)
            {
                string str = textBox1.Lines[i];
                string[] replace = str.Split(',');
                
               if ((Int32.Parse(replace[0]) >= 100 && Int32.Parse(replace[0]) <= 999) && (Int32.Parse(replace[2]) >= 1 && Int32.Parse(replace[2]) <= 31) && (Int32.Parse(replace[3]) >= 1 && Int32.Parse(replace[3]) <= 12) && (Int32.Parse(replace[4]) >= 1000 && Int32.Parse(replace[4]) <= 2010) && (double.Parse(replace[5]) >= 1.0f && double.Parse(replace[5]) <= 10.0f) && (Int32.Parse(replace[6])>=1 && Int32.Parse(replace[6]) <= 200))
               {
                    bsTreePanel1.AddNode(Int32.Parse(replace[0]), replace[1], Int32.Parse(replace[2]), Int32.Parse(replace[3]), Int32.Parse(replace[4]), double.Parse(replace[5]), Int32.Parse(replace[6]));
               }
               else
               {
                    textBox1.Clear();
                    textBox1.Text = "Error";
               }
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            if (searchKey.Checked && !searchName.Checked && !searchBD.Checked && !searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            {
                bsTreePanel1.searchKey(Int32.Parse(textBox1.Text));
            }else if (!searchKey.Checked && searchName.Checked && !searchBD.Checked && !searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            {
                //Console.WriteLine(replace[1]);
                bsTreePanel1.searchName(Int32.Parse(textBox1.Lines[0]), textBox1.Lines[1]);
            }else if(!searchKey.Checked && !searchName.Checked && searchBD.Checked && !searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            {
                string str = textBox1.Text;
                string[] replace = str.Split(',');
                bsTreePanel1.searchBD(Int32.Parse(replace[0]), Int32.Parse(replace[1]), Int32.Parse(replace[2]), Int32.Parse(replace[3]));
            }else if (!searchKey.Checked && !searchName.Checked && !searchBD.Checked && searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            {
                string str = textBox1.Text;
                string[] replace = str.Split(',');
                bsTreePanel1.searchAverageScore(Int32.Parse(replace[0]), Double.Parse(replace[1]));
            }else if (!searchKey.Checked && !searchName.Checked && !searchBD.Checked && !searchcumulativeAverageScore.Checked && searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            {
                string str = textBox1.Text;
                string[] replace = str.Split(',');
                bsTreePanel1.searchNumberOfCredits(Int32.Parse(replace[0]),Int32.Parse(replace[1]));
            }
            else if (!searchKey.Checked && !searchName.Checked && !searchBD.Checked && !searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && searchMin.Checked && !searchMax.Checked)
            {
                bsTreePanel1.searchMin();
            }else if (!searchKey.Checked && !searchName.Checked && !searchBD.Checked && !searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && searchMax.Checked)
            {
                bsTreePanel1.searchMax();
            }
            else
            {
                textBox1.Text = "Tick below please!";
            }

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            string str = textBox1.Text;
            string[] replace = str.Split(',');
            for (int i = 0; i < replace.Length; i++)
            {
                bsTreePanel1.DeleteNode(Int32.Parse(replace[i]));
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bsTreePanel1.prec(Int32.Parse(textBox1.Text));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bsTreePanel1.succ(Int32.Parse(textBox1.Text));
        }

        private void update_Click(object sender, EventArgs e)
        {

            if (!searchKey.Checked && searchName.Checked && !searchBD.Checked && !searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            { 
                bsTreePanel1.setName(Int32.Parse(textBox1.Lines[0]), textBox1.Lines[1]);
            }else if (!searchKey.Checked && !searchName.Checked && searchBD.Checked && !searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            {
                string str = textBox1.Text;
                string[] replace = str.Split(',');
                bsTreePanel1.setBD(Int32.Parse(replace[0]), Int32.Parse(replace[1]), Int32.Parse(replace[2]), Int32.Parse(replace[3]));
            }else if (!searchKey.Checked && !searchName.Checked && !searchBD.Checked && searchcumulativeAverageScore.Checked && !searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            {
                string str = textBox1.Text;
                string[] replace = str.Split(',');
                bsTreePanel1.setAverageScore(Int32.Parse(replace[0]), Double.Parse(replace[1]));
            }else if (!searchKey.Checked && !searchName.Checked && !searchBD.Checked && !searchcumulativeAverageScore.Checked && searchcumulativeNumberOfCredits.Checked && !searchMin.Checked && !searchMax.Checked)
            {
                string str = textBox1.Text;
                string[] replace = str.Split(',');
                bsTreePanel1.setNumberOfCredits(Int32.Parse(replace[0]), Int32.Parse(replace[1]));
            }
        }

        private void btnSaveImage_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Image img = new Bitmap(bsTreePanel1.Image);

                Graphics g = Graphics.FromImage(img);

                System.Drawing.Imaging.ImageFormat format;
                switch (saveFileDialog1.FilterIndex)
                {
                    case 1:
                        format = System.Drawing.Imaging.ImageFormat.Png;
                        break;
                    case 2:
                        format = System.Drawing.Imaging.ImageFormat.Jpeg;
                        g.Clear(Color.White);
                        break;
                    case 3:
                        format = System.Drawing.Imaging.ImageFormat.Bmp;
                        g.Clear(Color.White);
                        break;
                    default:
                        format = System.Drawing.Imaging.ImageFormat.Png; break;
                }

                img.Save(saveFileDialog1.FileName, format);
            }
        }
    }
}
