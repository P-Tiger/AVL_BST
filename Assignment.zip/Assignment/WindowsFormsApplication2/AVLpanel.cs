﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AVL;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Text.RegularExpressions;


namespace WindowsFormsApplication2
{
    public partial class AVLpanel : UserControl
    {
        #region Properties

        const int RADIUS = 30;
        const int DIAMETER = RADIUS * 2;
        const int HOR_DISTANCE = 70;
        const int VER_DISTANCE = 60;

        Pen _penNormal;
        Pen _penHighLight;
        Brush _brush;
        Font _font;

        AVL<int> _Tree;

        float _leftRoot;
        float _minLeft;
        float _maxLeft;

        public Image Image
        {
            get { return pictureBox1.Image; }
        }

        Graphics _g;

        Queue<int> _queue;

        public int NodeCount
        {
            get { return _Tree.count; }
        }
        public int TreeHeight
        {
            get { return _Tree.GetHeight(); }
        }
        #endregion

        public AVLpanel()
        {
            InitializeComponent();
            _brush = new LinearGradientBrush(new Rectangle(0, VER_DISTANCE / 2, 100, VER_DISTANCE),
        Color.LightSkyBlue, Color.White, LinearGradientMode.Vertical);
            _penNormal = new Pen(Color.DarkBlue, 2);
            _penHighLight = new Pen(Color.Red, 3);
            _font = new Font("Arial", 15);
            _Tree = new AVL<int>();
        }

        private void BeginDraw()
        {
            BeginDraw(false);
        }

        private void BeginDraw(bool resetAll)
        {

            if (resetAll)
            {
                if (pictureBox1.Image != null)
                    pictureBox1.Image.Dispose();

                _leftRoot = pictureBox1.Width / 2;
                _minLeft = _leftRoot;
                _maxLeft = _leftRoot;

                using (Graphics g = pictureBox1.CreateGraphics())
                {
                    CalculateSize(g, _leftRoot, _Tree.root);
                }



                _leftRoot -= _minLeft;
                if (_Tree.count < 4)
                    _leftRoot += 100;
                _maxLeft -= _minLeft;
                _minLeft = 0;

                _maxLeft += 250;
            }
            Image img = new Bitmap((int)_maxLeft, (_Tree.GetHeight() + 1) * VER_DISTANCE + 100);

            if (_g != null)
            {
                _g.Dispose();
                pictureBox1.Image.Dispose();
            }

            pictureBox1.Image = img;// new Bitmap(pictureBox1.Width, pictureBox1.Height);
            _g = Graphics.FromImage(pictureBox1.Image);
            _g.SmoothingMode = SmoothingMode.AntiAlias;
            DrawTreeNode(_g, new PointF(_leftRoot + 30, DIAMETER * 2), _Tree.root, true);
       //     Console.WriteLine(_Tree.root.value);
        }

        private void CalculateSize(Graphics g, float left, Node<int> node)
        {
            if (node != null)
            {
                string text = node.value.ToString();
                SizeF size = g.MeasureString(text, pictureBox1.Font);

                float x = left - (RADIUS + size.Width) / 2;

                if (node.HasLeft)
                {
                    float p2 = x - Math.Abs(HOR_DISTANCE + (node.value % 20) * 5);
                    if (p2 < _minLeft)
                        _minLeft = p2;
                    if (p2 > _maxLeft)
                        _maxLeft = p2;

                    CalculateSize(g, p2, node.left);
                }
                if (node.HasRight)
                {
                    float p2 = x + Math.Abs(HOR_DISTANCE + (node.value % 20) * 5);

                    if (p2 < _minLeft)
                        _minLeft = p2;
                    if (p2 > _maxLeft)
                        _maxLeft = p2;

                    CalculateSize(g, p2, node.right);
                }
            }
        }

        private void DrawTreeNode(Graphics g, PointF p, Node<int> node, bool highlight)
        {

            if (node != null)
            {
                string text = node.value.ToString();
                SizeF size = g.MeasureString(text, _font);

                float ellipseWidth = RADIUS + size.Width;
                float ellipseHeight = RADIUS + size.Height;

                float left = p.X - ellipseWidth / 2;
                float top = p.Y - ellipseHeight / 2;

                Pen pen = _penNormal;


                if (node.HasLeft)
                {
                    PointF p1 = p;
                    PointF p2 = p;

                    p1.X = left + ellipseWidth / 2;

                    p2.X -= Math.Abs(HOR_DISTANCE + (node.value % 20) * 5);
                    p2.Y += VER_DISTANCE;

                    bool hlight = false;

                    if (_queue != null && _queue.Count > 0)
                    {
                        if (_queue.Peek() == node.left.value)
                        {
                            _queue.Dequeue();
                            pen = _penHighLight;
                            hlight = true;
                        }
                    }
                    g.DrawLine(pen, p1, p2);

                    DrawTreeNode(g, p2, node.left, hlight);

                    if (p2.X < _minLeft)
                        _minLeft = p2.X;
                    if (p2.X > _maxLeft)
                        _maxLeft = p2.X;
                }
                if (node.HasRight)
                {
                    PointF p1 = p;
                    PointF p2 = p;
                    p1.X = left + ellipseWidth / 2;

                    p2.X += Math.Abs(HOR_DISTANCE + (node.value % 20) * 5);
                    p2.Y += VER_DISTANCE;

                    pen = _penNormal;
                    bool hlight = false;
                    if (_queue != null && _queue.Count > 0)
                    {
                        if (_queue.Peek() == node.right.value)
                        {
                            _queue.Dequeue();
                            pen = _penHighLight;
                            hlight = true;
                        }
                    }
                    g.DrawLine(pen, p1, p2);

                    DrawTreeNode(g, p2, node.right, hlight);

                    if (p2.X < _minLeft)
                        _minLeft = p2.X;
                    if (p2.X > _maxLeft)
                        _maxLeft = p2.X;
                }

                pen = highlight ? _penHighLight : _penNormal;

                g.FillEllipse(_brush, left, top, ellipseWidth, ellipseHeight);
                g.DrawEllipse(pen, left, top, ellipseWidth, ellipseHeight);

                g.DrawString(text, _font, Brushes.Black, left + RADIUS / 2, top + RADIUS / 2);

            }
        }

        public void randomTree()
        {
            _queue = null;
            _Tree.Clear();
            Random rnd = new Random();
            int[] key = new int[6];
            String[] name = new String[6];
            int[] day = new int[6];
            int[] month = new int[6];
            int[] year = new int[6];
            double[] cumulativeAverageScore = new double[6];
            int[] cumulativeNumberOfCredits = new int[6];
            for (int i = 0; i < 6; i++)
            {
                key[i] = rnd.Next(100, 999);
                // name
                if (key[i] < 200)
                {
                    name[i] = "Nguyen Van A";
                }
                else if (key[i] < 300)
                {
                    name[i] = "Nguyen Van B";
                }
                else if (key[i] < 400)
                {
                    name[i] = "Nguyen Van C";
                }
                else if (key[i] < 500)
                {
                    name[i] = "Nguyen Van D";
                }
                else if (key[i] < 600)
                {
                    name[i] = "Nguyen Van E";
                }
                else if (key[i] < 700)
                {
                    name[i] = "Nguyen Van F";
                }
                else if (key[i] < 800)
                {
                    name[i] = "Nguyen Van G";
                }
                else if (key[i] < 900)
                {
                    name[i] = "Nguyen Van H";
                }
                else if (key[i] < 1000)
                {
                    name[i] = "Nguyen Van I";
                }
                year[i] = rnd.Next(1000, 2010);
                month[i] = rnd.Next(1, 12);
                if (month[i] == 1 || month[i] == 3 || month[i] == 5 || month[i] == 7 || month[i] == 8 || month[i] == 10 || month[i] == 12)
                {
                    day[i] = rnd.Next(1, 31);
                }
                else if (month[i] == 2)
                {
                    day[i] = rnd.Next(1, 28);
                }
                else if (month[i] == 2 && ((year[i] % 4 == 0) && (year[i] % 100 != 0)) || (year[i] % 400 == 0))
                {
                    day[i] = rnd.Next(1, 28);
                }
                else
                {
                    day[i] = rnd.Next(1, 30);
                }
                cumulativeAverageScore[i] = getRanFloat(rnd.Next(4, 10));

                cumulativeNumberOfCredits[i] = rnd.Next(1, 200);

                _Tree.addNode(key[i], name[i], day[i], month[i], year[i], Math.Round(cumulativeAverageScore[i], 1), cumulativeNumberOfCredits[i]);
                
            }
            BeginDraw(true);
        }

        public double getRanFloat(int a)
        {
            Random rand = new Random();
            return rand.NextDouble() * a;
        }

        public void empty()
        {
            _Tree.Clear();
            BeginDraw(true);
        }

        public bool AddNode(int value, String name, int day, int month, int year, double cumulativeAverageScore, int cumulativeNumberOfCredits)
        {
           _Tree.addNode(value, name, day, month, year, cumulativeAverageScore, cumulativeNumberOfCredits);
            txtOutput.Clear();
            BeginDraw(true);
            return true;
        }

        public void LNR()
        {
            txtOutput.Clear();
            StringBuilder str = new StringBuilder("Left Node Right:\r\n");
            List<String> list = _Tree.LNR();
            list.ForEach(i => str.Append("[").Append(i).Append("]\r\n"));
            txtOutput.Text = str.ToString();
            list.Clear();
            list = null;
        }

        public void LRN()
        {
            txtOutput.Clear();
            StringBuilder str = new StringBuilder("Left Right Node:\r\n");
            List<String> list = _Tree.LRN();
            list.ForEach(i => str.Append("[").Append(i).Append("]\r\n"));
            txtOutput.Text = str.ToString();
            list.Clear();
            list = null;
        }

        public void NLR()
        {
            txtOutput.Clear();
            StringBuilder str = new StringBuilder("Node Left Right:\r\n");
            List<String> list = _Tree.NLR();
            list.ForEach(i => str.Append("[").Append(i).Append("]\r\n"));
            txtOutput.Text = str.ToString();
            list.Clear();
            list = null;
        }

        public void RNL()
        {
            txtOutput.Clear();
            StringBuilder str = new StringBuilder("Right Node Left:\r\n");
            List<String> list = _Tree.RNL();
            list.ForEach(i => str.Append("[").Append(i).Append("]\r\n"));
            txtOutput.Text = str.ToString();
            list.Clear();
            list = null;
        }

        public void NRL()
        {
            txtOutput.Clear();
            StringBuilder str = new StringBuilder("Node Right Left\r\n");
            List<String> list = _Tree.NRL();
            list.ForEach(i => str.Append("[").Append(i).Append("]\r\n"));
            txtOutput.Text = str.ToString();
            list.Clear();
            list = null;
        }

        public void RLN()
        {
            txtOutput.Clear();
            StringBuilder str = new StringBuilder("Right Left Node\r\n");
            List<String> list = _Tree.RLN();
            list.ForEach(i => str.Append("[").Append(i).Append("]\r\n"));
            txtOutput.Text = str.ToString();
            list.Clear();
            list = null;
        }

        public bool searchKey(int value)
        {
            _queue = _Tree.findPathKey(value);
            if (_queue == null)
            {
                txtOutput.Text = "Tree does not contain value " + value;
                txtOutput.SelectAll();
                return false;
            }
            txtOutput.Clear();
            BeginDraw();
            return true;
        }

        public bool searchName(int key, String name)
        {
            _queue = _Tree.findPathName(key, name);
            if (_queue == null)
            {
                txtOutput.Text = "Tree does not contain value " + name;
                txtOutput.SelectAll();
                return false;
            }
            txtOutput.Clear();
            BeginDraw();
            return true;
        }

        public bool searchBD(int key, int day, int month, int year)
        {
            _queue = _Tree.findPathBD(key, day, month, year);
            if (_queue == null)
            {
                txtOutput.Text = "Tree does not contain value " + day + "/" + month + "/" + year;
                txtOutput.SelectAll();
                return false;
            }
            txtOutput.Clear();
            BeginDraw();
            return true;
        }
        public bool searchAverageScore(int key, double AverageScore)
        {
            _queue = _Tree.findPathAverageScore(key, AverageScore);
            if (_queue == null)
            {
                txtOutput.Text = "Tree does not contain value " + AverageScore;
                txtOutput.SelectAll();
                return false;
            }
            txtOutput.Clear();
            BeginDraw();
            return true;
        }
        public bool searchNumberOfCredits(int key, int NumberOfCredits)
        {
            _queue = _Tree.findPathNumberOfCredits(key, NumberOfCredits);
            if (_queue == null)
            {
                txtOutput.Text = "Tree does not contain value " + NumberOfCredits;
                txtOutput.SelectAll();
                return false;
            }
            txtOutput.Clear();
            BeginDraw();
            return true;
        }

        public bool searchMin()
        {
            _queue = _Tree.findPathMin();
            txtOutput.Clear();
            BeginDraw();
            return true;
        }

        public bool searchMax()
        {
            _queue = _Tree.findPathMax();

            txtOutput.Clear();
            BeginDraw();
            return true;
        }

        public bool DeleteNode(int value)
        {
            _Tree.Remove(value);
            txtOutput.Clear();
            BeginDraw();
            return true;
        }

        public void prec(int key)
        {
            Node<int> pre = _Tree.Predecessor(_Tree.root, null, key);
            if ((pre == null || pre == _Tree.root))
            {
                txtOutput.Text = key + " has no predecessor.";
                txtOutput.SelectAll();
            }
            else
            {
                txtOutput.Text = "The predecessor of " + key + " is " + +pre.value;
                txtOutput.SelectAll();
            }
        }

        public void succ(int key)
        {
            Node<int> suc = _Tree.successor(_Tree.root, null, key);
            if ((suc == null || suc == _Tree.root))
            {
                txtOutput.Text = key + " has no successor.";
                txtOutput.SelectAll();
            }
            else
            {
                txtOutput.Text = "The predecessor of " + key + " is " + suc.value;
                txtOutput.SelectAll();

            }
        }

        public void setName(int key, String name)
        {
            _Tree.updateName(key, name);
        }
        public void setBD(int key, int day, int month, int year)
        {
            if ((day >= 1 && day <= 31) && (month >= 1 && month <= 12) && (year >= 1000 && year <= 2010))
                _Tree.updateBD(key, day, month, year);
            else
                txtOutput.Text = "error";
        }
        public void setAverageScore(int key, double Score)
        {
            if (Score >= 0.0 && Score <= 10.0)
                _Tree.updateAverageScore(key, Score);
            else
                txtOutput.Text = "error";
        }

        public void setNumberOfCredits(int key, int Score)
        {
            if (Score >= 1 && Score <= 200)
            {
                _Tree.updateNumberOfCredits(key, Score);
            }
        }

    }
}
