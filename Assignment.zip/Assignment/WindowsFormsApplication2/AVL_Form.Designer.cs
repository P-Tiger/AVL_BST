﻿namespace WindowsFormsApplication2
{
    partial class AVL_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AVL_Form));
            this.panel1 = new System.Windows.Forms.Panel();
            this.update = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.searchMax = new System.Windows.Forms.CheckBox();
            this.searchMin = new System.Windows.Forms.CheckBox();
            this.searchcumulativeNumberOfCredits = new System.Windows.Forms.CheckBox();
            this.searchcumulativeAverageScore = new System.Windows.Forms.CheckBox();
            this.searchBD = new System.Windows.Forms.CheckBox();
            this.searchName = new System.Windows.Forms.CheckBox();
            this.searchKey = new System.Windows.Forms.CheckBox();
            this.deleteButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.RLNButton = new System.Windows.Forms.Button();
            this.NRLButton = new System.Windows.Forms.Button();
            this.RNLButton = new System.Windows.Forms.Button();
            this.NLRButton = new System.Windows.Forms.Button();
            this.LRNButton = new System.Windows.Forms.Button();
            this.LNRButton = new System.Windows.Forms.Button();
            this.random = new System.Windows.Forms.Button();
            this.empty = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.btnSaveImage = new System.Windows.Forms.Button();
            this.avLpanel1 = new WindowsFormsApplication2.AVLpanel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnSaveImage);
            this.panel1.Controls.Add(this.update);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.searchMax);
            this.panel1.Controls.Add(this.searchMin);
            this.panel1.Controls.Add(this.searchcumulativeNumberOfCredits);
            this.panel1.Controls.Add(this.searchcumulativeAverageScore);
            this.panel1.Controls.Add(this.searchBD);
            this.panel1.Controls.Add(this.searchName);
            this.panel1.Controls.Add(this.searchKey);
            this.panel1.Controls.Add(this.deleteButton);
            this.panel1.Controls.Add(this.SearchButton);
            this.panel1.Controls.Add(this.addButton);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.RLNButton);
            this.panel1.Controls.Add(this.NRLButton);
            this.panel1.Controls.Add(this.RNLButton);
            this.panel1.Controls.Add(this.NLRButton);
            this.panel1.Controls.Add(this.LRNButton);
            this.panel1.Controls.Add(this.LNRButton);
            this.panel1.Controls.Add(this.random);
            this.panel1.Controls.Add(this.empty);
            this.panel1.Location = new System.Drawing.Point(787, 1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(292, 875);
            this.panel1.TabIndex = 4;
            // 
            // update
            // 
            this.update.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update.Location = new System.Drawing.Point(13, 371);
            this.update.Margin = new System.Windows.Forms.Padding(4);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(95, 52);
            this.update.TabIndex = 22;
            this.update.Text = "Set";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(136, 441);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(104, 37);
            this.button2.TabIndex = 21;
            this.button2.Text = "Successor ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 441);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 37);
            this.button1.TabIndex = 20;
            this.button1.Text = "Predecessor";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // searchMax
            // 
            this.searchMax.AutoSize = true;
            this.searchMax.Location = new System.Drawing.Point(13, 529);
            this.searchMax.Name = "searchMax";
            this.searchMax.Size = new System.Drawing.Size(104, 21);
            this.searchMax.TabIndex = 19;
            this.searchMax.Text = "Search Max";
            this.searchMax.UseVisualStyleBackColor = true;
            // 
            // searchMin
            // 
            this.searchMin.AutoSize = true;
            this.searchMin.Location = new System.Drawing.Point(13, 502);
            this.searchMin.Name = "searchMin";
            this.searchMin.Size = new System.Drawing.Size(101, 21);
            this.searchMin.TabIndex = 18;
            this.searchMin.Text = "Search Min";
            this.searchMin.UseVisualStyleBackColor = true;
            // 
            // searchcumulativeNumberOfCredits
            // 
            this.searchcumulativeNumberOfCredits.AutoSize = true;
            this.searchcumulativeNumberOfCredits.Location = new System.Drawing.Point(13, 661);
            this.searchcumulativeNumberOfCredits.Name = "searchcumulativeNumberOfCredits";
            this.searchcumulativeNumberOfCredits.Size = new System.Drawing.Size(273, 21);
            this.searchcumulativeNumberOfCredits.TabIndex = 17;
            this.searchcumulativeNumberOfCredits.Text = "Search Or Set With Number Of Credits";
            this.searchcumulativeNumberOfCredits.UseVisualStyleBackColor = true;
            // 
            // searchcumulativeAverageScore
            // 
            this.searchcumulativeAverageScore.AutoSize = true;
            this.searchcumulativeAverageScore.Location = new System.Drawing.Point(13, 637);
            this.searchcumulativeAverageScore.Name = "searchcumulativeAverageScore";
            this.searchcumulativeAverageScore.Size = new System.Drawing.Size(250, 21);
            this.searchcumulativeAverageScore.TabIndex = 16;
            this.searchcumulativeAverageScore.Text = "Search Or Set With Average Score";
            this.searchcumulativeAverageScore.UseVisualStyleBackColor = true;
            // 
            // searchBD
            // 
            this.searchBD.AutoSize = true;
            this.searchBD.Location = new System.Drawing.Point(13, 610);
            this.searchBD.Name = "searchBD";
            this.searchBD.Size = new System.Drawing.Size(214, 21);
            this.searchBD.TabIndex = 15;
            this.searchBD.Text = "Search Or Set With Birth Day";
            this.searchBD.UseVisualStyleBackColor = true;
            // 
            // searchName
            // 
            this.searchName.AutoSize = true;
            this.searchName.Location = new System.Drawing.Point(13, 583);
            this.searchName.Name = "searchName";
            this.searchName.Size = new System.Drawing.Size(193, 21);
            this.searchName.TabIndex = 14;
            this.searchName.Text = "Search Or Set With Name";
            this.searchName.UseVisualStyleBackColor = true;
            // 
            // searchKey
            // 
            this.searchKey.AutoSize = true;
            this.searchKey.Location = new System.Drawing.Point(13, 556);
            this.searchKey.Name = "searchKey";
            this.searchKey.Size = new System.Drawing.Size(135, 21);
            this.searchKey.TabIndex = 13;
            this.searchKey.Text = "Search With Key";
            this.searchKey.UseVisualStyleBackColor = true;
            // 
            // deleteButton
            // 
            this.deleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteButton.Location = new System.Drawing.Point(145, 371);
            this.deleteButton.Margin = new System.Windows.Forms.Padding(4);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Size = new System.Drawing.Size(95, 52);
            this.deleteButton.TabIndex = 12;
            this.deleteButton.Text = "Delete";
            this.deleteButton.UseVisualStyleBackColor = true;
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.Location = new System.Drawing.Point(145, 298);
            this.SearchButton.Margin = new System.Windows.Forms.Padding(4);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(95, 52);
            this.SearchButton.TabIndex = 12;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // addButton
            // 
            this.addButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton.Location = new System.Drawing.Point(13, 298);
            this.addButton.Margin = new System.Windows.Forms.Padding(4);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(95, 52);
            this.addButton.TabIndex = 11;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(13, 137);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(227, 55);
            this.textBox1.TabIndex = 10;
            // 
            // RLNButton
            // 
            this.RLNButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RLNButton.Location = new System.Drawing.Point(189, 808);
            this.RLNButton.Margin = new System.Windows.Forms.Padding(4);
            this.RLNButton.Name = "RLNButton";
            this.RLNButton.Size = new System.Drawing.Size(67, 52);
            this.RLNButton.TabIndex = 9;
            this.RLNButton.Text = "RLN";
            this.RLNButton.UseVisualStyleBackColor = true;
            this.RLNButton.Click += new System.EventHandler(this.RLNButton_Click);
            // 
            // NRLButton
            // 
            this.NRLButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NRLButton.Location = new System.Drawing.Point(104, 808);
            this.NRLButton.Margin = new System.Windows.Forms.Padding(4);
            this.NRLButton.Name = "NRLButton";
            this.NRLButton.Size = new System.Drawing.Size(67, 52);
            this.NRLButton.TabIndex = 8;
            this.NRLButton.Text = "NRL";
            this.NRLButton.UseVisualStyleBackColor = true;
            this.NRLButton.Click += new System.EventHandler(this.NRLButton_Click);
            // 
            // RNLButton
            // 
            this.RNLButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RNLButton.Location = new System.Drawing.Point(20, 808);
            this.RNLButton.Margin = new System.Windows.Forms.Padding(4);
            this.RNLButton.Name = "RNLButton";
            this.RNLButton.Size = new System.Drawing.Size(67, 52);
            this.RNLButton.TabIndex = 7;
            this.RNLButton.Text = "RNL";
            this.RNLButton.UseVisualStyleBackColor = true;
            this.RNLButton.Click += new System.EventHandler(this.RNLButton_Click);
            // 
            // NLRButton
            // 
            this.NLRButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NLRButton.Location = new System.Drawing.Point(189, 738);
            this.NLRButton.Margin = new System.Windows.Forms.Padding(4);
            this.NLRButton.Name = "NLRButton";
            this.NLRButton.Size = new System.Drawing.Size(67, 52);
            this.NLRButton.TabIndex = 6;
            this.NLRButton.Text = "NLR";
            this.NLRButton.UseVisualStyleBackColor = true;
            this.NLRButton.Click += new System.EventHandler(this.NLRButton_Click);
            // 
            // LRNButton
            // 
            this.LRNButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LRNButton.Location = new System.Drawing.Point(104, 738);
            this.LRNButton.Margin = new System.Windows.Forms.Padding(4);
            this.LRNButton.Name = "LRNButton";
            this.LRNButton.Size = new System.Drawing.Size(67, 52);
            this.LRNButton.TabIndex = 5;
            this.LRNButton.Text = "LRN";
            this.LRNButton.UseVisualStyleBackColor = true;
            this.LRNButton.Click += new System.EventHandler(this.LRNButton_Click);
            // 
            // LNRButton
            // 
            this.LNRButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNRButton.Location = new System.Drawing.Point(20, 738);
            this.LNRButton.Margin = new System.Windows.Forms.Padding(4);
            this.LNRButton.Name = "LNRButton";
            this.LNRButton.Size = new System.Drawing.Size(67, 52);
            this.LNRButton.TabIndex = 4;
            this.LNRButton.Text = "LNR";
            this.LNRButton.UseVisualStyleBackColor = true;
            this.LNRButton.Click += new System.EventHandler(this.LNRButton_Click);
            // 
            // random
            // 
            this.random.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.random.Location = new System.Drawing.Point(145, 11);
            this.random.Margin = new System.Windows.Forms.Padding(4);
            this.random.Name = "random";
            this.random.Size = new System.Drawing.Size(95, 93);
            this.random.TabIndex = 1;
            this.random.Text = "Random";
            this.random.UseVisualStyleBackColor = true;
            this.random.Click += new System.EventHandler(this.random_Click);
            // 
            // empty
            // 
            this.empty.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empty.Location = new System.Drawing.Point(13, 11);
            this.empty.Margin = new System.Windows.Forms.Padding(4);
            this.empty.Name = "empty";
            this.empty.Size = new System.Drawing.Size(95, 93);
            this.empty.TabIndex = 0;
            this.empty.Text = "Empty";
            this.empty.UseVisualStyleBackColor = true;
            this.empty.Click += new System.EventHandler(this.empty_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.DefaultExt = "*.png";
            this.saveFileDialog1.Filter = "PNG|*.png|JPEG|*.jpg|Bitmap|*.bmp";
            // 
            // btnSaveImage
            // 
            this.btnSaveImage.Location = new System.Drawing.Point(20, 220);
            this.btnSaveImage.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveImage.Name = "btnSaveImage";
            this.btnSaveImage.Size = new System.Drawing.Size(220, 54);
            this.btnSaveImage.TabIndex = 23;
            this.btnSaveImage.Text = "Save Image As...";
            this.btnSaveImage.UseVisualStyleBackColor = true;
            this.btnSaveImage.Click += new System.EventHandler(this.btnSaveImage_Click);
            // 
            // avLpanel1
            // 
            this.avLpanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.avLpanel1.Location = new System.Drawing.Point(2, 1);
            this.avLpanel1.Name = "avLpanel1";
            this.avLpanel1.Size = new System.Drawing.Size(778, 875);
            this.avLpanel1.TabIndex = 0;
            // 
            // AVL_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 876);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.avLpanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AVL_Form";
            this.Text = "Adelson-Velsky and Landis";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private AVLpanel avLpanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox searchMax;
        private System.Windows.Forms.CheckBox searchMin;
        private System.Windows.Forms.CheckBox searchcumulativeNumberOfCredits;
        private System.Windows.Forms.CheckBox searchcumulativeAverageScore;
        private System.Windows.Forms.CheckBox searchBD;
        private System.Windows.Forms.CheckBox searchName;
        private System.Windows.Forms.CheckBox searchKey;
        private System.Windows.Forms.Button deleteButton;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button RLNButton;
        private System.Windows.Forms.Button NRLButton;
        private System.Windows.Forms.Button RNLButton;
        private System.Windows.Forms.Button NLRButton;
        private System.Windows.Forms.Button LRNButton;
        private System.Windows.Forms.Button LNRButton;
        private System.Windows.Forms.Button random;
        private System.Windows.Forms.Button empty;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnSaveImage;
    }
}